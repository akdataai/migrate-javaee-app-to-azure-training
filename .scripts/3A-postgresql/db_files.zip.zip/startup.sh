#!/usr/bin/env bash
/opt/eap/bin/jboss-cli.sh -c --file=/home/site/scripts/postgresql-datasource-commands.cli